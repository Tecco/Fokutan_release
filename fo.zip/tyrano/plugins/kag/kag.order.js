tyrano.plugin.kag.order={tyrano:null,init:function(){this.tyrano.test()},test:function(){}};
